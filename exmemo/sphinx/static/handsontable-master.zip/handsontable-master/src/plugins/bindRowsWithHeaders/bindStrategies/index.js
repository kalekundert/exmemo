import Loose from './loose';
import Strict from './strict';

export {
  Loose,
  Strict,
};
